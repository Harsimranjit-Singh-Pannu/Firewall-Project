
import sys
from pathlib import Path
from importlib import import_module

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from engine.context import ExecutionContext

create_message_envelope = import_module(
    "scripts.simulate_firewall_message"
).create_message_envelope


class TestMessageReceiving:

    def test_create_message_envelope(self):
        envelope = create_message_envelope(
            sender="sender@example.com",
            recipient="recipient@example.com",
            text="Hello firewall",
            headers={"Subject": "Test message"},
        )

        assert envelope["message_id"]
        assert envelope["sender"] == "sender@example.com"
        assert envelope["recipient"] == "recipient@example.com"
        assert envelope["text"] == "Hello firewall"
        assert envelope["headers"] == {
            "Subject": "Test message"
        }

    def test_message_envelopes_have_unique_ids(self):
        first = create_message_envelope(
            sender="a@example.com",
            recipient="b@example.com",
            text="First message",
        )

        second = create_message_envelope(
            sender="a@example.com",
            recipient="b@example.com",
            text="Second message",
        )

        assert first["message_id"] != second["message_id"]

    def test_missing_headers_default_to_empty_dictionary(self):
        envelope = create_message_envelope(
            sender="sender@example.com",
            recipient="recipient@example.com",
            text="Hello",
        )

        assert envelope["headers"] == {}

    def test_headers_are_copied(self):
        headers = {"Subject": "Original"}

        envelope = create_message_envelope(
            sender="sender@example.com",
            recipient="recipient@example.com",
            text="Hello",
            headers=headers,
        )

        envelope["headers"]["Subject"] = "Changed"

        assert headers["Subject"] == "Original"

    def test_message_fields_can_be_loaded_into_execution_context(self):
        from engine.message_parameters import load_message_parameters

        envelope = create_message_envelope(
            sender="sender@example.com",
            recipient="recipient@example.com",
            text="Hello firewall",
            headers={"Subject": "Test message"},
        )

        context = ExecutionContext()

        load_message_parameters(envelope, context)

        assert context.get_parameter("Message-Id").value == envelope["message_id"]
        assert context.get_parameter("Message-Sender").value == "sender@example.com"
        assert context.get_parameter("Message-Recipient").value == "recipient@example.com"
        assert context.get_parameter("Message-Text").value == "Hello firewall"
        assert context.get_parameter("Message-Headers").value == {
            "Subject": "Test message"
        }
    
    def test_message_parameter_loader_rejects_missing_fields(self):
        from engine.message_parameters import load_message_parameters

        envelope = {
            "message_id": "test-123",
            "sender": "sender@example.com",
            "recipient": "recipient@example.com",
            "text": "Hello firewall",
            # headers intentionally missing
        }

        context = ExecutionContext()

        with pytest.raises(ValueError, match="headers"):
            load_message_parameters(envelope, context)

    def test_message_parameter_loader_rejects_non_dictionary_envelope(self):
        from engine.message_parameters import load_message_parameters

        context = ExecutionContext()

        with pytest.raises(ValueError, match="dictionary"):
            load_message_parameters("not a message", context)