from .factory import ComparatorFactory
